import numpy
arr = numpy.array([[[1, 2, 3], [4, 5, 6]], [[1, 2, 3], [4, 5, 6]]])

def flatten(matrix):
  matrix=matrix.flatten()
  return matrix
print(arr)
print(flatten(arr))